package com.Inheritance;
	
	public abstract class SweetProducer {
		
	    public abstract void produceSweet();
	    
 }
	
	
