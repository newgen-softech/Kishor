package com.encapsulation;

public class TestExample {

	public static void main(String[] args) {

		Employee e = new Employee();

		e.setAddress("USA");
		e.setId(101);
		e.setName("Prasad");

		System.out.println("addres  " + e.getAddress());
		System.out.println("id " + e.getId());
		System.out.println("name " + e.getName());

	}

}
