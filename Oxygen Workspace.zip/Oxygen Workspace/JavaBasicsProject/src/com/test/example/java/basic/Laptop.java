package com.test.example.java.basic;

public class Laptop {

	void m1() {

		
		/**
		 * @author Admin  hggfhgfhhgf
		 *
		 */
		
		System.out.println("from laptop classs and m1 method");

	}

	public void Table() {
		// TODO Auto-generated method stub
		
	}

}
