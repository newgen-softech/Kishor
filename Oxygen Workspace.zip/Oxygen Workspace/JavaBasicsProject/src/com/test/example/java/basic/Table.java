/**
 * 
 */
package com.test.example.java.basic;

/**
 * @author Admin
 *
 */
public class Table {

	public static void main(String[] args) {

		int intValue = 5;// veriable

		
		
		
		String strName = "Prasad 987987@ 65465@@#$%%^";

		System.out.println("Hellow World " + intValue + " " + strName);

		testMethod();



	}

	private static void testMethod() {
		// TODO Auto-generated method stub

		System.out.println("from method");

	}

}
