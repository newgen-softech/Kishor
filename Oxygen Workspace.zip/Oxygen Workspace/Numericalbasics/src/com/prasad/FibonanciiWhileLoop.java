package com.prasad;

public class FibonanciiWhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
