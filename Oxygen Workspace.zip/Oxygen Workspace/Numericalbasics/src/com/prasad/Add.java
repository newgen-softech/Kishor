package com.prasad;


import java.util.*;
import javafx.application.*;

public class Add {

	

	    static int solveMeFirst(int a, int b ) {
	             return a+b;
	      	// Hint: Type return a+b; below 

	   }

	 public static void main(String[] args) {
	        Scanner Scanner = new Scanner(System.in);
	        int a;
	        a = in.nextInt();
	        int b;
	        b = in.nextInt();
	        int sum;
	        sum = solveMeFirst(a, b);
	        System.out.println(sum);
	   }
	}
