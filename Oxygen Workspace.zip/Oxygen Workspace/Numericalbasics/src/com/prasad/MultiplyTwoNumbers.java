package com.prasad;

public class MultiplyTwoNumbers {

	public static void main(String[] args) {
		
		        float first = 1.5f;
		        float second = 2.0f;
		        float product = first * second;
		        System.out.println("The product is: " + product);
		    }
		}

	

