package com.collectionEx;

import java.util.*;
public class ArrayLisFullEX {

	public static void main(String[] args) {

	      
	      ArrayList<String> obj = new ArrayList<String>();

	     
	      obj.add("Prasad");
	      obj.add("Aniket");
	      obj.add("Vicky");
	      obj.add("Bhushan");
	      obj.add("Chetan");

	     
	      System.out.println("Original ArrayList:");
	      
	      for(String str:obj)
	    	  
	         System.out.println(str);

	  
	      obj.add(0, "Rahul");
	      obj.add(1, "Vaishali");

	     
	      System.out.println("ArrayList after add operation:");
	      for(String str:obj)
	         System.out.println(str);

	      
	      obj.remove("Aniket");
	      obj.remove("Vicky"); 

	      
	      System.out.println("ArrayList after remove operation:");
	      for(String str:obj)
	         System.out.println(str);

	      
	      obj.remove(1);
	      System.out.println("Final ArrayList:");
	      
	      for(String str:obj)
	    	  
	         System.out.println(str);

	}

}
