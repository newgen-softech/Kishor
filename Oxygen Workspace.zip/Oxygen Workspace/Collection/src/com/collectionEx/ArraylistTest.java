package com.collectionEx;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class ArraylistTest {

	public static void main(String[] args) {
		
		ArrayList<String> al = new ArrayList<String>();
		
		al.add("Ducati Motorsport");
		
		al.add("BMW AG");
		
		al.add("Suzuki Motors");
		
		System.out.println(al.add("Honda Motors"));
		
		al.size();
		System.out.println(al.size());
		
		al.isEmpty();
		System.out.println("Iteration of arraylist by for loop");
		
		for(int i = 0; i < al.size(); i++) {
			
			System.out.println(al.get(i));
		}

		System.out.println("iteration of Array list by Iterator");
		
		Iterator<String> itr = al.iterator();
		
		while (itr.hasNext()) {
		
		Object o = itr.next();
		
		String s = (String)o;
		
		System.out.println(s);
		
	}
		
		System.out.println("iteration of array list by list iterater");
		
		ListIterator<String> ltr = al.listIterator();
	    
		while(ltr.hasNext()) {
			
        Object o = ltr.next();
		
		String s = (String) o;
		
		System.out.println(s);
		}
	
	}
}	
		
		
		
		
		
		
		
		

