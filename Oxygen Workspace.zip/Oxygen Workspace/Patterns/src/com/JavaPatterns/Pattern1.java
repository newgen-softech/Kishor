package com.JavaPatterns;

public class Pattern1 {

	public static void main(String[] args) {
		
		@SuppressWarnings("unused")
		int p = 6;
		
		for(int i= 1; i<= 5; i++) { //outer loop for number of rows(n)
			
			for (int j= 1; j<=5; j++) { //inner loop for number of columns
				
				if(j>5-i) {
					
				System.out.print(" *");
			}
				
			    else {
			System.out.print(" ");  
			    }
			
		  }
			System.out.println(" ");
			
	 } 
		
		
		for(int k=1; k<=6; k++) {
			
			for(int l=5; l>=1; l--) {
				
				if(l<=5-k) {
					
					System.out.print(" *");
				}
				
				else {
					System.out.print(" ");
				}
				
	}
			System.out.println(" ");
			
	     }
	}

}




